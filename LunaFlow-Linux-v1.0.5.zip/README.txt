# LunaFlow Desktop Agent (Linux)

## Installation
1. Extract the archive.
2. Make executable: `chmod +x LunaFlow.Desktop`
3. Run: `./LunaFlow.Desktop`

## Getting Started
1. Open your browser to http://localhost:5000
2. username admin pass admin123

## Systemd Service (Optional)
To run as a background service:
1. Edit `lunaflow.service` to match your path.
2. `sudo cp lunaflow.service /etc/systemd/system/`
3. `sudo systemctl enable --now lunaflow`

## Support
Visit: https://github.com/lunasoft/lunaflow
