# LunaFlow Desktop Agent (Windows)

## Installation
1. Extract the folder.
2. Run `LunaFlow.Desktop.exe`.

## Getting Started
1. Open your browser to http://localhost:5000
2. **First Run**: Check `initial_admin_password.txt` for your random admin password.

## Note
This version is Self-Contained. You do NOT need to install .NET.
