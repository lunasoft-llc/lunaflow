# LunaFlow Desktop Agent (Windows)

## Installation
1. Extract the folder.
2. Run `LunaFlow.Desktop.exe`.

## Getting Started
1. Open your browser to http://localhost:5000
2. username admin pass admin123
## Note
This version is Self-Contained. You do NOT need to install .NET.
