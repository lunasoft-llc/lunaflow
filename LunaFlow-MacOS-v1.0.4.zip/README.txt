# LunaFlow Desktop Agent (MacOS)

## Installation
1. Extract the archive.
2. Open Terminal.
3. Make executable: `chmod +x LunaFlow.Desktop`
4. Run: `./LunaFlow.Desktop`

## Note
If you see a security warning:
1. Go to System Settings -> Privacy & Security.
2. Click 'Open Anyway' for LunaFlow.
